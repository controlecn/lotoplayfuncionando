<?php

/////////////////////////////////////////////////////////////////
//===============================================================
// adminlogin_lang.php(languages/english/admin)
//===============================================================
// AEF : Advanced Electron Forum 
// Version : 1.0.8
// Inspired by Pulkit and taken over by Electron
// Extract text from admin files by oxlo (16th January 2008).
// --------------------------------------------------------------
// Started by: Electron, Ronak Gupta, Pulkit Gupta
// Date:       23rd Jan 2006
// Time:       15:00 hrs
// Site:       http://www.anelectron.com/ (Anelectron)
// --------------------------------------------------------------
// Please Read the Terms of use at http://www.anelectron.com
// --------------------------------------------------------------
//===============================================================
// (c)Electron Inc.
//===============================================================
/////////////////////////////////////////////////////////////////

$l['no_password'] = 'You did not enter your Password.';
$l['password_invalid'] = 'You have entered an invalid password.';

//Theme Strings
$l['<title>'] = 'Administration Center - Login';
$l['security_login'] = 'Security Login';
$l['username'] = 'Username';
$l['password'] = 'Password';
$l['submit'] = 'Submit';

?>